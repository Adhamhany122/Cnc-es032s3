# Custom ESP32-S3 hardware integration

Changes on top of stock FluidNC 4.1.0. See `example_configs/ESP32-S3_CNC_Router.yaml`
for the full machine config.

## New files
- `FluidNC/src/PowerLossRecovery.h/.cpp` -- ISR-driven power-loss detection,
  high-priority SD fast-save, modal-state snapshot/restore, resume prompt
  (`power_loss_recovery:` YAML key)
- `FluidNC/src/PCF8574Keypad.h/.cpp` -- 3x4 I2C matrix keypad, debounce,
  jog auto-repeat, realtime/system command dispatch (`keypad:`)
- `FluidNC/src/Buzzer.h/.cpp` -- LEDC tone generation, startup melody,
  reusable `Buzzer::beep()` (`buzzer:`)
- `FluidNC/esp32/SH1106_I2C.h/.cpp` -- SH1106 page-addressing-mode driver for
  the existing `OLEDDisplay` base class (the same thingpulse SSD1306 library
  FluidNC already depends on)

## Modified files
- `FluidNC/esp32/OLED.h/.cpp` -- added `controller: sh1106|ssd1306` and
  `sh1106_column_offset:` config items; added job-runtime tracking/display;
  added the "Resume job?" prompt screen (reads `PLR::promptPending()`)
- `FluidNC/include/Driver/PwmPin.h`, `FluidNC/esp32/PwmPin.cpp` -- added
  `PwmPin::setFrequency()` so the Buzzer can retune one permanently-allocated
  LEDC channel per note instead of exhausting the 4-independent-channel
  budget `allocateChannel()` hands out
- `platformio.ini` -- removed the `-<../esp32/OLED.cpp>` exclusion from
  `[common_esp32s3]` (see the comment left in place of it for why it was
  safe to remove); no new `lib_deps` -- SH1106 support reuses the SSD1306
  library already pinned there

## Review pass (post-write, pre-compile)
Re-read every new/modified file against the actual source a second time and
fixed four real issues found that way (not simulated — each was located by
grepping/viewing the real declaration it depended on):
- `PowerLossRecovery.cpp`: `stripSdPrefix()` was defined *after* `doSave()`,
  which calls it -- both are free functions in the same anonymous namespace,
  so this would not have compiled. Reordered.
- `PowerLossRecovery.cpp`: `doSave()` called `Job::active()` and then
  separately `Job::source()`. `Job.h`'s own header comment documents that
  the job stack can be mutated between two such calls from another task, and
  says to take one consistent reference instead. Changed to a single
  `Job::source()` call.
- `PCF8574Keypad.cpp` / `OLED.cpp`: `i2c_num` is read as a plain `uint8_t`
  with no YAML-level upper bound, then used to index `config->_i2c[]`
  directly -- a typo'd value (e.g. `i2c_num: 5` on a board with 2 buses)
  indexes out of bounds. Added an explicit `>= MAX_N_I2C` check in both
  (OLED's was pre-existing stock behavior, tightened here since that file
  was already being touched for SH1106 support).
- `esp32/PwmPin.cpp`: the new `setFrequency()` didn't check
  `ledc_set_freq()`'s return value. Low-stakes for a buzzer specifically,
  but added error logging on failure since it's now shared infrastructure.
- **`platformio.ini` -- the significant one.** This repo builds nine
  environments by default (`default_envs`), not just `wifi_s3`/`noradio_s3`:
  classic ESP32, RP2040, and RP2350 targets, plus non-default
  windows_x86/macos/linux/wasm simulator ("capture") targets and a
  `tests`/`tests_coverage` pair. The three new `src/` files are matched by
  the same `+<**/*.cpp>` glob those other environments use too.
  `PowerLossRecovery.cpp` calls raw ESP-IDF `driver/gpio.h`/`esp_timer.h`
  functions with no RP2040 or simulator equivalent, and would not have
  compiled there at all; `PCF8574Keypad.cpp` depends on
  `PowerLossRecovery.h`'s `PLR::` functions and on `Machine::I2CBus` (itself
  already excluded from the simulator targets in the stock repo), so it
  goes with it; `Buzzer.cpp` depends on `PwmPin`, which does now have a
  working `setFrequency()` on every backend (see below) but wasn't worth
  gambling FreeRTOS-API parity on for a platform you're not building for.
  Added `-<PowerLossRecovery.cpp> -<PCF8574Keypad.cpp> -<Buzzer.cpp>` to
  `build_src_filter` in `common_pico_base` (covers all four rp2040/rp2350
  envs via its `extends` chain), `[env:windows_x86]`, `[posix_common]`
  (covers macos/linux/linux_x86_64), and `[env:wasm]` -- the same four
  places `-<SSD1306_I2C.cpp>` is already excluded, matching that existing
  convention. `tests`/`tests_coverage` use a small explicit whitelist, not
  a glob, so they were never affected. Classic (non-S3) ESP32 needed no
  change -- same ESP-IDF family as S3, so the code compiles there too, it's
  only the YAML pin map that's S3-specific.
  `Driver/PwmPin.h`'s `setFrequency()` is implemented on all three PwmPin
  backends now (`esp32/`, `rp2040/`, `capture/`), not only esp32/, since it
  was little extra work to keep that shared interface complete rather than
  working on only the one backend this project happens to target.

## Known limitations / things to verify on real hardware
This was developed and reviewed against the actual FluidNC 4.1.0 source (not
written from memory), but could not be compiled or run in this environment --
no network access to fetch the PlatformIO toolchain/libraries, so there was
no `pio run` to confirm it builds clean. Build it yourself before flashing,
and in particular check these in order of how likely they are to need a
small fix:

1. **PLR resume (`PLR::confirmResume()` in PowerLossRecovery.cpp)** is the
   piece most worth testing deliberately (small test file, machine at a
   known position) before trusting it on a real job: the filename
   round-trip through `$SD/Run=` strips a `/sd` prefix based on how
   `FluidPath` is expected to canonicalize paths, and the byte-offset seek
   uses `JobSource::set_position()`/`setLineNumber()`, which this change
   reuses rather than invents, but its exact timing relative to `$SD/Run=`
   finishing wasn't something that could be executed here to confirm.
2. **SH1106 init (`SH1106_I2C::sendInitSequence()`).** The inherited
   `OLEDDisplay::init()` (from the pinned thingpulse library) may send its
   own SSD1306-oriented commands first; `sendInitSequence()` is called
   right after it specifically to leave the panel in a known-good state
   regardless, but this library's exact internals weren't inspectable here.
3. **`power_loss_recovery.detect_pin: gpio.48`** -- no pin was specified
   for this in the original hardware spec; gpio.48 was chosen as unused
   elsewhere in the map, free at the silicon level (only a board-level RGB
   LED on some ESP32-S3-DevKitC-1 revisions). Confirm against your own
   schematic.
4. Every `steps_per_mm` / `max_rate_mm_per_min` / `acceleration_mm_per_sec2`
   in the YAML is a reasonable placeholder, not a measured value -- tune
   each axis before cutting anything.

## Review pass 2 (static review, still NOT compiled)
- `example_configs/ESP32-S3_CNC_Router.yaml`: `stepping: engine: RMT` is not a
  valid value on this S3 build (`MAX_N_RMT 0`) -- the config would have failed
  to load. Changed to `Timed`.
- `PowerLossRecovery.cpp` `confirmResume()`: `execute_line(..., false)` only
  *queues* lines for the protocol task, so `Job::source()` right after
  `$SD/Run=` was always null and the seek never happened -- the file restarted
  from line 0. The seek is now applied inside `runFile()` (FileCommands.cpp)
  via a weak hook `plr_take_resume_seek()`, before the job starts.
- Resume now refuses unless the machine is Idle (i.e. homed after boot), keeps
  the saved state and the prompt if not, and the keypad HOME key works while
  the prompt is showing.
- Resume repositioning is now: raise Z to `safe_z_mpos_mm` -> XY -> spindle/
  coolant -> slow G1 plunge (all G53/mm) -> restore units/distance/WCS/feed.
  Previously it was one simultaneous G0 X Y Z.
- Keypad task stack 3072 -> 4096 (snprintf with %f).
- Known limitation, not fixed: the saved line/byte offset is the *read-ahead*
  position (lines already in the planner), not the block executing at power
  loss, so a few motion lines can be skipped on resume. Motion mode
  (G0/G1/G2/G3), G92 and tool-length offsets are not restored.
