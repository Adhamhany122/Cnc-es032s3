#include "PCF8574Keypad.h"

#include "Machine/MachineConfig.h"
#include "Machine/I2CBus.h"
#include "PowerLossRecovery.h"
#include "RealtimeCmd.h"
#include "Settings.h"   // execute_line
#include "Serial.h"     // allChannels
#include "NutsBolts.h"  // get_ms()
#include "Logging.h"
#include "string_util.h"  // to_hex()

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <cstdio>
#include <cstring>

namespace {

    // PCF8574 bit assignment -- see the wiring table in PCF8574Keypad.h.
    constexpr uint8_t kRowBits[3] = { 0, 1, 2 };
    constexpr uint8_t kColBits[4] = { 3, 4, 5, 6 };

    enum class KeyAction : uint8_t {
        JogXNeg,
        JogXPos,
        JogYPos,
        JogZPos,
        JogYNeg,
        JogZNeg,
        Home,
        Reset,
        FeedHold,
        CycleStart,
        Start,
        Stop,
        None,
    };

    // [row][col], matching the silkscreen table in the header.
    constexpr KeyAction kKeyMap[3][4] = {
        { KeyAction::JogXNeg, KeyAction::JogXPos, KeyAction::JogYPos, KeyAction::JogZPos },
        { KeyAction::JogYNeg, KeyAction::JogZNeg, KeyAction::Home, KeyAction::Reset },
        { KeyAction::FeedHold, KeyAction::CycleStart, KeyAction::Start, KeyAction::Stop },
    };

    bool isJogAction(KeyAction a) {
        switch (a) {
            case KeyAction::JogXNeg:
            case KeyAction::JogXPos:
            case KeyAction::JogYPos:
            case KeyAction::JogYNeg:
            case KeyAction::JogZPos:
            case KeyAction::JogZNeg:
                return true;
            default:
                return false;
        }
    }

    void jogAxisAndSign(KeyAction a, char& axis, int& sign) {
        switch (a) {
            case KeyAction::JogXNeg:
                axis = 'X';
                sign = -1;
                break;
            case KeyAction::JogXPos:
                axis = 'X';
                sign = 1;
                break;
            case KeyAction::JogYPos:
                axis = 'Y';
                sign = 1;
                break;
            case KeyAction::JogYNeg:
                axis = 'Y';
                sign = -1;
                break;
            case KeyAction::JogZPos:
                axis = 'Z';
                sign = 1;
                break;
            case KeyAction::JogZNeg:
                axis = 'Z';
                sign = -1;
                break;
            default:
                axis = '?';
                sign = 0;
                break;
        }
    }

    struct ScanContext {
        Machine::I2CBus* i2c;
        uint8_t           address;
        uint32_t          debounce_ms;
        uint32_t          repeat_ms;
        float             jog_step_mm;
        float             jog_feed;
    };

    bool scanRow(ScanContext& ctx, int row, uint8_t& colBits) {
        uint8_t out = 0xFF & ~(1 << kRowBits[row]);  // drive this row low, leave everything else high
        if (ctx.i2c->write(ctx.address, &out, 1) < 0) {
            return false;
        }
        uint8_t in = 0xFF;
        if (ctx.i2c->read(ctx.address, &in, 1) < 0) {
            return false;
        }
        colBits = in;
        return true;
    }

    void releaseAllRows(ScanContext& ctx) {
        uint8_t out = 0xFF;
        ctx.i2c->write(ctx.address, &out, 1);
    }

    // One-shot actions: realtime commands and $H. Never called for jog
    // actions -- those are handled by fireJogStart()/fireJogStop() so they
    // can be started on press and cancelled on release.
    void fireAction(KeyAction a) {
        if (PLR::promptPending()) {
            // Start/Stop double as the Yes/No answer to the resume prompt, and
            // Home is allowed (resume needs a homed machine). Every other key
            // is ignored so a stray press can't jog or start a cycle before
            // the operator has answered.
            if (a == KeyAction::Start) {
                PLR::confirmResume();
            } else if (a == KeyAction::Stop) {
                PLR::cancelResume();
            } else if (a == KeyAction::Home) {
                // Machine position is lost at power-off, so homing has to be
                // possible while the prompt is up -- resume refuses to run
                // until the machine is homed and Idle.
                execute_line("$H", allChannels, AuthenticationLevel::LEVEL_ADMIN, false);
            }
            return;
        }

        switch (a) {
            case KeyAction::Home:
                execute_line("$H", allChannels, AuthenticationLevel::LEVEL_ADMIN, false);
                break;
            case KeyAction::Reset:
            case KeyAction::Stop:
                execute_realtime_command(Cmd::Reset, allChannels);
                break;
            case KeyAction::FeedHold:
                execute_realtime_command(Cmd::FeedHold, allChannels);
                break;
            case KeyAction::CycleStart:
            case KeyAction::Start:
                execute_realtime_command(Cmd::CycleStart, allChannels);
                break;
            default:
                break;
        }
    }

    void fireJogStart(KeyAction a, ScanContext& ctx) {
        if (PLR::promptPending()) {
            return;
        }
        char axis;
        int  sign;
        jogAxisAndSign(a, axis, sign);
        char line[48];
        snprintf(line, sizeof(line), "$J=G91 %c%.3f F%.1f", axis, sign * ctx.jog_step_mm, (double)ctx.jog_feed);
        execute_line(line, allChannels, AuthenticationLevel::LEVEL_ADMIN, false);
    }

    void fireJogStop() { execute_realtime_command(Cmd::JogCancel, allChannels); }

    void keypadTask(void* arg) {
        auto ctx = static_cast<ScanContext*>(arg);

        releaseAllRows(*ctx);  // ensure a known idle state (all rows high) before the first scan

        int8_t   active_key   = -1;  // row*4+col of the key currently debounced/held, or -1
        uint32_t stable_since = 0;
        uint32_t last_repeat  = 0;
        bool     confirmed    = false;
        bool     held_is_jog  = false;

        for (;;) {
            vTaskDelay(pdMS_TO_TICKS(10));

            int8_t found_key = -1;
            for (int row = 0; row < 3 && found_key < 0; ++row) {
                uint8_t colBits;
                if (!scanRow(*ctx, row, colBits)) {
                    continue;  // transient I2C error -- retry on the next tick
                }
                for (int col = 0; col < 4; ++col) {
                    if (!(colBits & (1 << kColBits[col]))) {  // active-low: this key is pressed
                        found_key = (int8_t)(row * 4 + col);
                        break;
                    }
                }
            }
            releaseAllRows(*ctx);

            uint32_t now = get_ms();

            if (found_key != active_key) {
                if (confirmed && held_is_jog) {
                    fireJogStop();
                }
                active_key   = found_key;
                stable_since = now;
                confirmed    = false;
                held_is_jog  = false;
                continue;
            }

            if (active_key < 0) {
                continue;  // nothing pressed
            }

            KeyAction action = kKeyMap[active_key / 4][active_key % 4];

            if (!confirmed) {
                if (now - stable_since < ctx->debounce_ms) {
                    continue;  // still settling
                }
                confirmed   = true;
                held_is_jog = isJogAction(action);
                if (held_is_jog) {
                    fireJogStart(action, *ctx);
                    last_repeat = now;
                } else {
                    fireAction(action);
                }
                continue;
            }

            if (held_is_jog && (now - last_repeat >= ctx->repeat_ms)) {
                fireJogStart(action, *ctx);
                last_repeat = now;
            }
        }
    }
}

void PCF8574Keypad::group(Configuration::HandlerBase& handler) {
    // @config i2c_num
    // @default 0
    // Which top-level i2cN: bus the keypad is wired to.
    handler.item("i2c_num", _i2c_num);

    // @config i2c_address
    // @default 0x20
    // PCF8574 address (0x20-0x27 on the base part with A0-A2 strapped; 0x38-0x3F on the
    // PCF8574A variant). Must match how the module's address pins are strapped.
    handler.item("i2c_address", _address);

    // @config debounce_ms
    // @default 30
    // How long a key must read consistently pressed before it is acted on.
    handler.item("debounce_ms", _debounce_ms, 5, 200);

    // @config repeat_ms
    // @default 120
    // While a jog key (X+/X-/Y+/Y-/Z+/Z-) is held past debounce_ms, a new incremental jog
    // command is issued every repeat_ms. Action keys (Home/Reset/Feed Hold/Cycle
    // Start/Start/Stop) are one-shot and are not affected by this.
    handler.item("repeat_ms", _repeat_ms, 30, 1000);

    // @config jog_step_mm
    // @default 1.0
    // Distance, in mm, moved per jog repeat while a jog key is held.
    handler.item("jog_step_mm", _jog_step_mm, 0.01f, 50.0f);

    // @config jog_feed_mm_per_min
    // @default 800.0
    handler.item("jog_feed_mm_per_min", _jog_feed, 1.0f, 20000.0f);

    // @config enabled
    // @default true
    handler.item("enabled", _enabled);
}

void PCF8574Keypad::validate() {}

void PCF8574Keypad::afterParse() {
    // i2c_num has no YAML-level upper bound (see group() -- it's taken as a
    // plain uint8_t), so a typo'd value must be checked against the real
    // bus count before it is used to index config->_i2c[], or an
    // out-of-range value reads out of bounds.
    if (_i2c_num >= MAX_N_I2C) {
        log_config_error("keypad: i2c_num " << int(_i2c_num) << " is out of range (this board has " << MAX_N_I2C << " I2C bus(es))");
        _error = true;
        return;
    }
    if (!config->_i2c[_i2c_num]) {
        log_config_error("keypad: i2c" << _i2c_num << " section must be defined");
        _error = true;
    }
}

void PCF8574Keypad::init() {
    if (_error || !_enabled) {
        return;
    }

    static ScanContext ctx;  // outlives init(); the task holds a pointer to it
    ctx.i2c         = config->_i2c[_i2c_num];
    ctx.address     = _address;
    ctx.debounce_ms = (uint32_t)_debounce_ms;
    ctx.repeat_ms   = (uint32_t)_repeat_ms;
    ctx.jog_step_mm = _jog_step_mm;
    ctx.jog_feed    = _jog_feed;

    xTaskCreatePinnedToCore(keypadTask, "keypad_scan", 4096, &ctx, 3, nullptr, 1);

    log_info("Keypad: PCF8574 @ " << to_hex(_address) << " on i2c" << _i2c_num);
}

void PCF8574Keypad::deinit() {}

ConfigurableModuleFactory::InstanceBuilder<PCF8574Keypad> __keypad_module("keypad");
