#include "WallPlotter.h"

#include "Machine/MachineConfig.h"
#include "Limit.h"

#include <cmath>

namespace Kinematics {
    void WallPlotter::group(Configuration::HandlerBase& handler) {
        // A puck suspended by two cords, positioned by adjusting each cord's length --
        // e.g. a wall-mounted plotter/drawbot. Each cord is driven by one machine axis,
        // measured as cord length rather than a cartesian coordinate.

        // @config left_axis
        // @default 0
        // @tuning typical
        // Which machine axis index drives the left cord's length.
        // NOT bounds-checked against MAX_N_AXIS -- see transform_cartesian_to_motors()
        // below for why an out-of-range or Z-and-above value here is unsafe.
        handler.item("left_axis", _left_axis);

        // @config left_anchor_x
        // @default -100
        // @tuning per-machine
        // X position of the left cord's fixed anchor point, in the cartesian frame.
        handler.item("left_anchor_x", _left_anchor_x);

        // @config left_anchor_y
        // @default 100
        // @tuning per-machine
        // Y position of the left cord's fixed anchor point.
        handler.item("left_anchor_y", _left_anchor_y);

        // @config right_axis
        // @default 1
        // @tuning typical
        // Which machine axis index drives the right cord's length.
        // NOT bounds-checked -- see left_axis above.
        handler.item("right_axis", _right_axis);

        // @config right_anchor_x
        // @default 100
        // @tuning per-machine
        // X position of the right cord's fixed anchor point.
        handler.item("right_anchor_x", _right_anchor_x);

        // @config right_anchor_y
        // @default 100
        // @tuning per-machine
        // Y position of the right cord's fixed anchor point.
        handler.item("right_anchor_y", _right_anchor_y);

        // @config segment_length
        // @default 10
        // @tuning typical
        // Maximum length of the small linear segments a cartesian move is broken into
        // before being converted to cord lengths (the cord-length transform is nonlinear).
        handler.item("segment_length", _segment_length);
    }

    void WallPlotter::init() {
        log_info("Kinematic system: " << name());

        // We assume the machine starts at cartesian (0, 0, 0).
        // The motors assume they start from (0, 0, 0).
        // So we need to derive the zero lengths to satisfy the kinematic equations.
        xy_to_lengths(0, 0, zero_left, zero_right);
        last_motor_segment_end[0] = zero_left;
        last_motor_segment_end[1] = zero_right;
        auto n_axis               = Axes::_numberAxis;
        for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
            last_motor_segment_end[axis] = 0.0;
        }

        init_position();
    }

    // Initialize the machine position
    void WallPlotter::init_position() {
        // Same as cartesian
        auto  n_axis = Axes::_numberAxis;
        float min_mpos[MAX_N_AXIS];
        float max_mpos[MAX_N_AXIS];

        for (axis_t axis = X_AXIS; axis < n_axis; axis++) {
            set_steps(axis, 0);  // Set to zeros
            min_mpos[axis] = limitsMinPosition(axis);
            max_mpos[axis] = limitsMaxPosition(axis);
        }
        transform_cartesian_to_motors(_min_motor_pos, min_mpos);
        transform_cartesian_to_motors(_max_motor_pos, max_mpos);
    }

    bool WallPlotter::canHome(AxisMask axisMask) {
        log_error("This kinematic system cannot home");
        return false;
    }

    bool WallPlotter::transform_cartesian_to_motors(float* motors, float* cartesian) {
        float left_length, right_length;
        xy_to_lengths(cartesian[X_AXIS], cartesian[Y_AXIS], left_length, right_length);

        // Inverse of the mapping used in motors_to_cartesian() (left motor runs backward).
        //
        // KNOWN ISSUE: _left_axis/_right_axis come straight from config with no
        // validation. An out-of-range value is an out-of-bounds write into motors[];
        // a value >= Z_AXIS gets silently overwritten by the copy loop below, which
        // would produce wrong (not crashing) soft-limit bounds. Same unchecked
        // pattern already existed in motors_to_cartesian()'s reads of motors[_left_axis]/
        // motors[_right_axis] before this function was implemented -- flagged in PR
        // review (bdring/FluidNC#1771) as worth a real fix (bounds-check in validate()),
        // just not folded into that PR.
        motors[_left_axis]  = 0 - (left_length - zero_left);
        motors[_right_axis] = 0 + (right_length - zero_right);

        auto n_axis = Axes::_numberAxis;
        for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
            motors[axis] = cartesian[axis];
        }
        return true;
    }

    /*
      cartesian_to_motors() converts from cartesian coordinates to motor space.

      All linear motions pass through cartesian_to_motors() to be planned as mc_move_motors operations.

      Parameters:
        target = an n_axis array of target positions (where the move is supposed to go)
        pl_data = planner data (see the definition of this type to see what it is)
        position = an n_axis array of where the machine is starting from for this move
    */
    bool WallPlotter::cartesian_to_motors(float* target, plan_line_data_t* pl_data, float* position) {
        auto n_axis = Axes::_numberAxis;

        float total_cartesian_distance = vector_distance(position, target, n_axis);
        if (total_cartesian_distance == 0) {
            mc_move_motors(target, pl_data);
            return true;
        }

        float cartesian_feed_rate = pl_data->feed_rate;

        // calculate the total X,Y axis move distance
        // Z axis is the same in both coord systems, so it does not undergo conversion
        float xydist = vector_distance(target, position, 2);  // Only compute distance for both axes. X and Y
        // Segment our G1 and G0 moves based on yaml file. If we choose a small enough _segment_length we can hide the nonlinearity
        uint32_t segment_count = xydist / _segment_length;
        if (segment_count < 1) {  // Make sure there is at least one segment, even if there is no movement
            // We need to do this to make sure other things like S and M codes get updated properly by
            // the planner even if there is no movement??
            segment_count = 1;
        }
        float cartesian_segment_length = total_cartesian_distance / segment_count;

        // Calc length of each cartesian segment - the same for all segments
        float cartesian_segment_components[MAX_N_AXIS];
        for (axis_t axis = X_AXIS; axis < n_axis; axis++) {
            cartesian_segment_components[axis] = (target[axis] - position[axis]) / segment_count;
        }

        float cartesian_segment_end[MAX_N_AXIS];
        copyAxes(cartesian_segment_end, position);

        // Calculate desired cartesian feedrate distance ratio. Same for each seg.
        for (uint32_t segment = 1; segment <= segment_count; segment++) {
            if (sys.abort()) {
                return true;
            }
            // calculate the cartesian end point of the next segment
            for (axis_t axis = X_AXIS; axis < n_axis; axis++) {
                cartesian_segment_end[axis] += cartesian_segment_components[axis];
            }

            // Convert cartesian space coords to motor space
            float motor_segment_end[MAX_N_AXIS];
            xy_to_lengths(cartesian_segment_end[X_AXIS], cartesian_segment_end[Y_AXIS], motor_segment_end[0], motor_segment_end[1]);
            for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
                motor_segment_end[axis] = cartesian_segment_end[axis];
            }

#ifdef USE_CHECKED_KINEMATICS
            // Check the inverse computation.
            float cx, cy;
            lengths_to_xy(motor_segment_end[0], motor_segment_end[1], cx, cy);

            if (abs(cartesian_segment_end[X_AXIS] - cx) > 0.1 || abs(cartesian_segment_end[Y_AXIS] - cy) > 0.1) {
                // FIX: Produce an alarm state?
            }
#endif
            // Adjust feedrate by the ratio of the segment lengths in motor and cartesian spaces,
            // accounting for all axes
            if (!pl_data->motion.rapidMotion) {  // Rapid motions ignore feedrate. Don't convert.
                                                 // T=D/V, Tcart=Tmotor, Dcart/Vcart=Dmotor/Vmotor
                                                 // Vmotor = Dmotor*(Vcart/Dcart)
                float motor_segment_length = vector_distance(last_motor_segment_end, motor_segment_end, n_axis);
                pl_data->feed_rate         = cartesian_feed_rate * motor_segment_length / cartesian_segment_length;
            }

            // TODO: G93 pl_data->motion.inverseTime logic?? Does this even make sense for wallplotter?

            // Remember the last motor position so the length can be computed the next time
            copyAxes(last_motor_segment_end, motor_segment_end);

            // Initiate motor movement with converted feedrate and converted position
            // mc_move_motors() returns false if a jog is cancelled.
            // In that case we stop sending segments to the planner.
            // Note that the left motor runs backward.
            // TODO: It might be better to adjust motor direction in .yaml file by inverting direction pin??
            float cables[MAX_N_AXIS];
            cables[0] = 0 - (motor_segment_end[0] - zero_left);
            cables[1] = 0 + (motor_segment_end[1] - zero_right);
            for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
                cables[axis] = cartesian_segment_end[axis];
            }
            if (!mc_move_motors(cables, pl_data)) {
                // TODO fixup last_left last_right?? What is position state when jog is cancelled?
                return false;
            }
        }
        return true;
    }

    /*
      The status command uses motors_to_cartesian() to convert
      your motor positions to cartesian X,Y,Z... coordinates.

      Convert the n_axis array of motor positions to cartesian in your code.
    */
    void WallPlotter::motors_to_cartesian(float* cartesian, float* motors, axis_t n_axis) {
        // The motors start at zero, but effectively at zero_left, so we need to correct for the computation.
        // Note that the left motor runs backward.
        // TODO: It might be better to adjust motor direction in .yaml file by inverting direction pin??

        float absolute_x, absolute_y;
        lengths_to_xy((0 - motors[_left_axis]) + zero_left, (0 + motors[_right_axis]) + zero_right, absolute_x, absolute_y);

        cartesian[X_AXIS] = absolute_x;
        cartesian[Y_AXIS] = absolute_y;
        for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
            cartesian[axis] = motors[axis];
        }
        // Now we have numbers that if fed back into the system should produce the same values.
    }

    /*
    Kinematic equations

    See http://paulbourke.net/geometry/circlesphere/

    First calculate the distance d between the center of the circles. d = ||P1 - P0||.

    If d > r0 + r1 then there are no solutions, the circles are separate.
    If d < |r0 - r1| then there are no solutions because one circle is contained within the other.
    If d = 0 and r0 = r1 then the circles are coincident and there are an infinite number of solutions.
    Considering the two triangles P0P2P3 and P1P2P3 we can write
    a2 + h2 = r02 and b2 + h2 = r12
    Using d = a + b we can solve for a,

    a = (r02 - r12 + d2 ) / (2 d)
    It can be readily shown that this reduces to r0 when the two circles touch at one point, ie: d = r0 ± r1

    Solve for h by substituting a into the first equation, h2 = r02 - a2

    h = sqrt(r02 - a2)
    */

    void WallPlotter::lengths_to_xy(float left_length, float right_length, float& x, float& y) {
        float distance  = _right_anchor_x - _left_anchor_x;
        float distance2 = distance * distance;

        // The lengths are the radii of the circles to intersect.
        float left_radius  = left_length;
        float left_radius2 = left_radius * left_radius;

        float right_radius  = right_length;
        float right_radius2 = right_radius * right_radius;

        // Compute a and h.
        float a  = (left_radius2 - right_radius2 + distance2) / (2 * distance);
        float a2 = a * a;
        float h  = sqrtf(left_radius2 - a2);

        // Translate to absolute coordinates.
        x = _left_anchor_x + a;
        y = _left_anchor_y - h;  // flip
    }

    void WallPlotter::xy_to_lengths(float x, float y, float& left_length, float& right_length) {
        // Compute the hypotenuse of each triangle.

        float left_dy = _left_anchor_y - y;
        float left_dx = _left_anchor_x - x;
        left_length   = hypot_f(left_dx, left_dy);

        float right_dy = _right_anchor_y - y;
        float right_dx = _right_anchor_x - x;
        right_length   = hypot_f(right_dx, right_dy);
    }

    bool WallPlotter::kinematics_homing(AxisMask& axisMask) {
        return false;  // kinematics does not do the homing for catesian systems
    }

    // Configuration registration
    namespace {
        KinematicsFactory::InstanceBuilder<WallPlotter> registration("WallPlotter");
    }
}
