// Copyright (c) 2026 - Custom ESP32-S3 hardware integration
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

// PCF8574Keypad
// -------------
// Drives a 3x4 (12-button) matrix keypad through a PCF8574 I2C I/O
// expander and maps it to machine control actions. Scanning, debounce and
// (for jog keys) auto-repeat run on a dedicated low-priority FreeRTOS task
// created in init() -- see Module.h: this is a ConfigurableModule, and
// ConfigurableModules are never polled by a central loop in this version of
// FluidNC (only init() is called on them), so a self-contained task is used
// instead of a Module::poll() override.
//
// Wiring (fixed by the PCF8574's 8 quasi-bidirectional I/Os -- not made
// YAML-configurable since it is a one-time hardware wiring decision, not
// something that varies per installation the way the I2C bus/address do):
//   P0-P2  -> keypad rows    R1 R2 R3   (driven low one at a time to scan)
//   P3-P6  -> keypad columns C1 C2 C3 C4 (read back; pulled up via the
//                                         PCF8574's own weak internal pull-ups)
//   P7     -> unused
//
// Key layout and action mapping (3 rows x 4 columns = 12 keys). The user's
// hardware spec named 10 of these 12 explicitly (X+/X-, Y+/Y-, Start, Stop,
// Home, Reset, Feed Hold, Cycle Start); Z+/Z- fill the remaining two slots,
// since the machine has a Z axis with its own stepper and limit switch and
// jogging it is the next most operationally useful control after X/Y:
//
//          C1            C2            C3           C4
//   R1     X-            X+            Y+           Z+
//   R2     Y-            Z-            HOME         RESET
//   R3     FEED_HOLD     CYCLE_START   START        STOP
//
// FluidNC's realtime command set (see RealtimeCmd.h) has a single
// start/resume primitive and a single abort primitive, not separate ones
// for "start" vs "cycle start" or "stop" vs "reset" -- so those pairs are
// intentionally wired to the same underlying action in normal operation.
// They stop being redundant the moment a saved power-loss session is
// pending: Start/Stop are then repurposed as the Yes/No answer to the
// "Resume job?" prompt (see PowerLossRecovery.h), which is also why those
// two specific keys -- not Cycle Start/Reset -- were chosen for that role.

#pragma once

#include "Module.h"
#include "Pin.h"

#include <cstdint>

class PCF8574Keypad : public ConfigurableModule {
public:
    explicit PCF8574Keypad(const char* name) : ConfigurableModule(name) {}

    PCF8574Keypad(const PCF8574Keypad&)            = delete;
    PCF8574Keypad(PCF8574Keypad&&)                 = delete;
    PCF8574Keypad& operator=(const PCF8574Keypad&) = delete;
    PCF8574Keypad& operator=(PCF8574Keypad&&)      = delete;

    void init() override;
    void deinit() override;

    void validate() override;
    void afterParse() override;
    void group(Configuration::HandlerBase& handler) override;

    ~PCF8574Keypad() override = default;

private:
    uint8_t _i2c_num     = 0;
    uint8_t _address     = 0x20;
    int32_t _debounce_ms = 30;
    int32_t _repeat_ms   = 120;
    float   _jog_step_mm = 1.0f;
    float   _jog_feed    = 800.0f;
    bool    _enabled     = true;

    bool _error = false;
};
