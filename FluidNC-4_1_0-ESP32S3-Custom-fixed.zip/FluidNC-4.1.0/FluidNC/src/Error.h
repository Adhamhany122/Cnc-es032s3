// Copyright (c) 2014-2016 Sungeun K. Jeon for Gnea Research LLC
// Copyright (c) 2018 -	Bart Dring
// Copyright (c) 2020 - Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#pragma once

#include <map>
#include <cstdint>
#include <exception>

// Error codes. Valid values (0-255)
enum class Error : uint8_t {
    Ok                           = 0,
    ExpectedCommandLetter        = 1,
    BadNumberFormat              = 2,
    InvalidStatement             = 3,
    NegativeValue                = 4,
    SettingDisabled              = 5,
    SettingStepPulseMin          = 6,
    SettingReadFail              = 7,
    IdleError                    = 8,
    SystemGcLock                 = 9,
    SoftLimitError               = 10,
    Overflow                     = 11,
    MaxStepRateExceeded          = 12,
    CheckDoor                    = 13,
    LineLengthExceeded           = 14,
    TravelExceeded               = 15,
    InvalidJogCommand            = 16,
    SettingDisabledLaser         = 17,
    HomingNoCycles               = 18,
    SingleAxisHoming             = 19,
    GcodeUnsupportedCommand      = 20,
    GcodeModalGroupViolation     = 21,
    GcodeUndefinedFeedRate       = 22,
    GcodeCommandValueNotInteger  = 23,
    GcodeAxisCommandConflict     = 24,
    GcodeWordRepeated            = 25,
    GcodeNoAxisWords             = 26,
    GcodeInvalidLineNumber       = 27,
    GcodeValueWordMissing        = 28,
    GcodeUnsupportedCoordSys     = 29,
    GcodeG53InvalidMotionMode    = 30,
    GcodeAxisWordsExist          = 31,
    GcodeNoAxisWordsInPlane      = 32,
    GcodeInvalidTarget           = 33,
    GcodeArcRadiusError          = 34,
    GcodeNoOffsetsInPlane        = 35,
    GcodeUnusedWords             = 36,
    GcodeG43DynamicAxisError     = 37,
    GcodeMaxValueExceeded        = 38,
    PParamMaxExceeded            = 39,
    CheckStartupPins             = 40,
    FsFailedMount                = 60,  // Filesystem failed to mount
    FsFailedRead                 = 61,  // Failed to read file
    FsFailedOpenDir              = 62,  // Failed to open directory
    FsDirNotFound                = 63,  // Directory not found
    FsFileEmpty                  = 64,  // File is empty
    FsFileNotFound               = 65,  // File not found
    FsFailedOpenFile             = 66,  // Failed to open file
    FsFailedBusy                 = 67,  // Filesystem is busy
    FsFailedDelDir               = 68,
    FsFailedDelFile              = 69,
    FsFailedRenameFile           = 70,
    NumberRange                  = 80,  // Setting number range problem
    InvalidValue                 = 81,  // Setting string problem
    FsFailedCreateFile           = 82,
    FsFailedFormat               = 83,
    MessageFailed                = 90,
    NvsSetFailed                 = 100,
    NvsGetStatsFailed            = 101,
    AuthenticationFailed         = 110,
    Eol                          = 111,
    Eof                          = 112,  // Not necessarily an error
    Reset                        = 113,
    NoData                       = 114,  // Not necessarily an error
    Deferred                     = 115,  // Internal: handed to cmd_queue, ack comes later
    AnotherInterfaceBusy         = 120,
    JogCancelled                 = 130,
    BadPinSpecification          = 150,
    BadRuntimeConfigSetting      = 151,
    ConfigurationInvalid         = 152,
    UploadFailed                 = 160,
    DownloadFailed               = 161,
    ReadOnlySetting              = 162,
    ExpressionDivideByZero       = 170,
    ExpressionInvalidArgument    = 171,
    ExpressionInvalidResult      = 172,
    ExpressionUnknownOp          = 173,
    ExpressionArgumentOutOfRange = 174,
    ExpressionSyntaxError        = 175,
    FlowControlSyntaxError       = 176,
    FlowControlNotExecutingMacro = 177,
    FlowControlOutOfMemory       = 178,
    FlowControlStackOverflow     = 179,
    ParameterAssignmentFailed    = 180,
    GcodeValueWordInvalid        = 181,
};

const char* errorString(Error errorNumber);

extern const std::map<Error, const char*> ErrorNames;

// Exception wrapper for Error enum to allow proper C++ exception handling
class ErrorException : public std::exception {
private:
    Error _error;

public:
    explicit ErrorException(Error err) noexcept : _error(err) {}

    Error error() const noexcept { return _error; }

    const char* what() const noexcept override {
        // Return a simple static string - avoid any dynamic allocation
        return "File operation failed";
    }
};
