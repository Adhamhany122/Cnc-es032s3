#include "PowerLossRecovery.h"

#include "Machine/MachineConfig.h"
#include "Machine/Axes.h"
#include "System.h"
#include "Report.h"
#include "GCode.h"
#include "SpindleDatatypes.h"
#include "Job.h"
#include "FluidPath.h"
#include "Settings.h"  // execute_line
#include "Serial.h"    // allChannels
#include "Logging.h"
#include "Buzzer.h"
#include "State.h"

#include <driver/gpio.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <cstring>
#include <cstdio>

// ---------------------------------------------------------------------------
// Internal engine. Kept as free functions in an anonymous namespace (rather
// than private members) so the ISR and the dedicated save task -- which
// outlive any particular call into the PowerLossRecovery object -- have a
// stable, simple surface to call into. The PowerLossRecovery class itself is
// a thin YAML-configuration holder that sets this engine up in init().
// ---------------------------------------------------------------------------
namespace {
    constexpr uint32_t kMagic          = 0x464E4C52;  // 'FNLR'
    constexpr uint32_t kVersion        = 1;
    constexpr int64_t  kGlitchGuardUs  = 2000;  // ignore re-triggers within 2ms of the last one

    SemaphoreHandle_t s_trigger_sem     = nullptr;
    volatile int64_t  s_last_trigger_us = 0;

    std::string s_state_path;  // resolved FluidPath string, set by init()
    bool        s_ready = false;

    bool            s_prompt_pending = false;
    PLR::SavedState s_pending_state {};
    char            s_prompt_text[96] = { 0 };

    // Seek request handed to FileCommands.cpp's runFile() through
    // plr_take_resume_seek() (defined at the bottom of this file). The seek
    // has to be applied to the InputFile *before* Job::nest() starts it
    // streaming: execute_line(..., on_protocol_task=false) only queues the
    // "$SD/Run=" line for the protocol task, so there is no job yet when
    // confirmResume() returns, and seeking afterwards (the old approach)
    // silently did nothing and restarted the file from line 0.
    bool     s_seek_pending = false;
    char     s_seek_file[96] = { 0 };
    uint32_t s_seek_pos      = 0;
    uint32_t s_seek_line     = 0;
    float    s_safe_z_mpos   = 0.0f;  // machine-coordinate Z that is clear of the workpiece

    uint32_t computeChecksum(const PLR::SavedState& s) {
        // Rotate-XOR accumulator over every field except the checksum itself.
        // This is a corruption guard for a torn/partial write, not a
        // cryptographic hash.
        const uint8_t* p   = reinterpret_cast<const uint8_t*>(&s);
        size_t         n   = offsetof(PLR::SavedState, checksum);
        uint32_t       sum = kMagic;
        for (size_t i = 0; i < n; ++i) {
            sum = ((sum << 5) | (sum >> 27)) ^ (uint32_t)p[i];
        }
        return sum;
    }

    void buildSummary(const PLR::SavedState& s) {
        snprintf(s_prompt_text, sizeof(s_prompt_text), "%.24s Ln%lu X%.1f Y%.1f", s.filename, (unsigned long)s.line_number,
                 (double)s.mpos[0], (double)s.mpos[1]);
    }

    // Channel::name() on an SD-backed JobSource returns the canonicalized
    // FluidPath, e.g. "/sd/gcode/part.nc". $SD/Run= (see FileCommands.cpp:
    // runSDFile -> runFile(SD, ...) -> openFile) resolves its parameter
    // against the sd: volume already, so the leading "/sd" mount prefix must
    // be stripped before round-tripping the name back through $SD/Run=, or
    // it would be applied twice.
    void stripSdPrefix(char* name) {
        constexpr const char* kPrefix    = "/sd";
        constexpr size_t      kPrefixLen = 3;
        if (strncmp(name, kPrefix, kPrefixLen) == 0) {
            memmove(name, name + kPrefixLen, strlen(name + kPrefixLen) + 1);
        }
    }

    // Runs on the dedicated high-priority save task, immediately after the
    // ISR wakes it. Keep this path short: no logging to a channel (that can
    // block on buffering/flow control), no heap allocation.
    void doSave() {
        // Job.h documents that callers needing a consistent view across
        // several fields should make one call (source()/channel(), which is
        // nullptr when idle) rather than active() followed by a second,
        // separate call -- the job stack can be mutated from another task
        // between the two. So this takes src once, up front, rather than
        // checking Job::active() and then separately calling Job::source().
        auto src = Job::source();
        if (!src) {
            return;  // Nothing worth saving if no SD job is running
        }

        PLR::SavedState s {};
        s.magic   = kMagic;
        s.version = kVersion;

        axis_t n_axis = Machine::Axes::_numberAxis;
        if (n_axis > 4) {
            n_axis = (axis_t)4;
        }
        s.n_axis = (uint8_t)n_axis;

        float* mpos = get_mpos();
        for (uint8_t i = 0; i < s.n_axis; ++i) {
            s.mpos[i] = mpos[i];
        }

        s.units_inch    = gc_state.modal.units == Units::Inches ? 1 : 0;
        s.distance_rel  = gc_state.modal.distance == Distance::Incremental ? 1 : 0;
        s.coord_select  = (uint8_t)gc_state.modal.coord_select;
        s.feed_rate     = gc_state.feed_rate;
        s.spindle_state = (uint8_t)gc_state.modal.spindle;
        s.spindle_speed = gc_state.spindle_speed;
        s.coolant_mist  = gc_state.modal.coolant.Mist;
        s.coolant_flood = gc_state.modal.coolant.Flood;

        s.filename[0] = '\0';
        s.line_number = 0;
        s.byte_offset = 0;

        auto ch = src->channel();
        if (ch) {
            strncpy(s.filename, ch->name(), sizeof(s.filename) - 1);
            s.filename[sizeof(s.filename) - 1] = '\0';
            stripSdPrefix(s.filename);
        }
        s.line_number = (uint32_t)src->lineNumber();
        s.byte_offset = (uint32_t)src->position();

        if (s.filename[0] == '\0') {
            return;  // No identifiable file -- nothing to resume later
        }

        s.checksum = computeChecksum(s);

        FILE* f = fopen(s_state_path.c_str(), "wb");
        if (!f) {
            return;
        }
        fwrite(&s, sizeof(s), 1, f);
        fflush(f);
        fclose(f);
    }

    void IRAM_ATTR plrISR(void* arg) {
        int64_t now = esp_timer_get_time();
        if (now - s_last_trigger_us < kGlitchGuardUs) {
            return;
        }
        s_last_trigger_us = now;

        BaseType_t woken = pdFALSE;
        xSemaphoreGiveFromISR(s_trigger_sem, &woken);
        if (woken == pdTRUE) {
            portYIELD_FROM_ISR();
        }
    }

    void saveTask(void* arg) {
        for (;;) {
            xSemaphoreTake(s_trigger_sem, portMAX_DELAY);
            doSave();
        }
    }

    bool loadSavedState(PLR::SavedState& out) {
        FILE* f = fopen(s_state_path.c_str(), "rb");
        if (!f) {
            return false;
        }
        size_t n = fread(&out, 1, sizeof(out), f);
        fclose(f);
        if (n != sizeof(out)) {
            return false;
        }
        if (out.magic != kMagic || out.version != kVersion) {
            return false;
        }
        if (out.checksum != computeChecksum(out)) {
            return false;
        }
        return out.filename[0] != '\0';
    }

    void clearSavedState() { remove(s_state_path.c_str()); }
}

// ---------------------------------------------------------------------------
// Public interface used by the Keypad and Display modules.
// ---------------------------------------------------------------------------
namespace PLR {

    bool promptPending() { return s_prompt_pending; }

    const char* promptSummary() { return s_prompt_text; }

    void confirmResume() {
        if (!s_prompt_pending) {
            return;
        }
        // Machine position is lost at power-off, so the saved machine
        // coordinates mean nothing until the machine has been homed again.
        // Keep the prompt (and the saved file) alive and let the operator
        // press HOME first, rather than queuing moves that would be rejected
        // or, worse, run from an unknown position.
        if (!state_is(State::Idle)) {
            log_info("PLR: machine must be homed and Idle before resuming -- press HOME, then START again");
            Buzzer::beep(440, 200);
            return;
        }

        s_prompt_pending  = false;
        SavedState s      = s_pending_state;
        const bool onTask = false;  // Called from the keypad task: lines are queued for the protocol task, in order

        auto run = [&](const char* line) { execute_line(line, allChannels, AuthenticationLevel::LEVEL_ADMIN, onTask); };

        char cmd[112];

        // 1. Do all repositioning in absolute machine coordinates, in mm, so
        //    the job's own units / distance mode / WCS (restored in step 4)
        //    cannot change what these numbers mean. Z goes to a safe height
        //    first, XY travels at that height, and only then does Z come back
        //    down -- at a controlled feed, not a rapid.
        run("G21 G90");
        snprintf(cmd, sizeof(cmd), "G53 G0 Z%.3f", (double)s_safe_z_mpos);
        run(cmd);
        snprintf(cmd, sizeof(cmd), "G53 G0 X%.3f Y%.3f", (double)s.mpos[0], (double)s.mpos[1]);
        run(cmd);

        // 2. Spindle / coolant back on before the plunge (M3/M4 honours the
        //    configured spin-up delay).
        if (s.spindle_state == (uint8_t)SpindleState::Cw || s.spindle_state == (uint8_t)SpindleState::Ccw) {
            snprintf(cmd, sizeof(cmd), "%s S%.0f", s.spindle_state == (uint8_t)SpindleState::Cw ? "M3" : "M4", (double)s.spindle_speed);
            run(cmd);
        }
        if (s.coolant_flood) {
            run("M8");
        }
        if (s.coolant_mist) {
            run("M7");
        }

        // 3. Plunge back to the saved depth at a slow feed.
        if (s.n_axis >= 3) {
            float plunge = (s.feed_rate > 0.0f && s.feed_rate < 300.0f) ? s.feed_rate : 300.0f;
            snprintf(cmd, sizeof(cmd), "G53 G1 Z%.3f F%.1f", (double)s.mpos[2], (double)plunge);
            run(cmd);
        }

        // 4. Now restore the modal state the saved line depended on: units,
        //    distance mode, active WCS and feed rate. This covers what nearly
        //    every job needs; a G92 offset, tool length offset, or the
        //    G0/G1/G2/G3 motion mode in effect at the cut are NOT restored.
        snprintf(cmd, sizeof(cmd), "G%d G%d G%d F%.3f", s.units_inch ? 20 : 21, s.distance_rel ? 91 : 90,
                 54 + (s.coord_select <= 5 ? s.coord_select : 0), (double)s.feed_rate);
        run(cmd);

        // 5. Re-open the file through the normal SD-run path. The seek is
        //    applied by runFile() itself, before the job starts streaming.
        strncpy(s_seek_file, s.filename, sizeof(s_seek_file) - 1);
        s_seek_file[sizeof(s_seek_file) - 1] = '\0';
        s_seek_pos     = s.byte_offset;
        s_seek_line    = s.line_number;
        s_seek_pending = true;

        char runcmd[128];
        snprintf(runcmd, sizeof(runcmd), "$SD/Run=%s", s.filename);
        run(runcmd);

        clearSavedState();
        log_info("PLR: resuming " << s.filename << " at line " << s.line_number);
    }

    void cancelResume() {
        if (!s_prompt_pending) {
            return;
        }
        s_prompt_pending = false;
        clearSavedState();
        log_info("PLR: saved job discarded");
    }
}

// ---------------------------------------------------------------------------
// ConfigurableModule glue
// ---------------------------------------------------------------------------
void PowerLossRecovery::group(Configuration::HandlerBase& handler) {
    // @config detect_pin
    // @default NO_PIN
    // @pin_attributes input
    // GPIO that senses an impending power loss (driven by an external
    // brown-out/voltage-drop detector backed by hold-up capacitors). Use the
    // pin string's own :low modifier if your sense circuit pulls the line
    // low to signal a loss, and :pu if you need the internal pull-up.
    handler.item("detect_pin", _detectPin);

    // @config state_file
    // @default "/plr_state.bin"
    // Path on the sd: volume where the fast-save snapshot is written. Keep
    // this at the root of the card -- deep paths cost extra SPI transactions
    // during the save.
    handler.item("state_file", _stateFile);

    // @config safe_z_mpos_mm
    // @default 0
    // Machine-coordinate Z (mm) that is clear of the workpiece. On resume,
    // Z is raised here before XY travels back to the saved position. 0 is
    // the top of travel on a machine that homes Z at its positive end with
    // mpos_mm: 0.
    handler.item("safe_z_mpos_mm", _safeZ, -10000.0f, 10000.0f);

    // @config enabled
    // @default true
    handler.item("enabled", _enabled);
}

void PowerLossRecovery::validate() {
    if (_enabled && _detectPin.undefined()) {
        log_config_error("power_loss_recovery: detect_pin must be set when enabled");
        _error = true;
    }
}

void PowerLossRecovery::afterParse() {}

void PowerLossRecovery::init() {
    if (_error || !_enabled) {
        return;
    }

    std::error_code ec;
    FluidPath       path(_stateFile, SD, ec);
    if (ec) {
        log_error("power_loss_recovery: cannot resolve state_file path " << _stateFile.c_str());
        return;
    }
    s_state_path = path.string();
    s_safe_z_mpos = _safeZ;

    _detectPin.setAttr(Pin::Attr::Input);

    s_trigger_sem = xSemaphoreCreateBinary();
    if (!s_trigger_sem) {
        log_error("power_loss_recovery: failed to create trigger semaphore");
        return;
    }

    // Deliberately bypass FluidNC's generic pin-event/ISR path -- see the
    // header comment for why. Install our own minimal, IRAM-resident ISR on
    // both edges is unnecessary; we only care about the transition into the
    // "power is failing" state, so a single edge direction is used,
    // determined by whether the pin's own :low modifier is set.
    gpio_num_t gpio = (gpio_num_t)_detectPin.getNative(Pin::Capabilities::Input);

    gpio_install_isr_service(ESP_INTR_FLAG_IRAM);  // Returns an (ignorable) error if already installed elsewhere
    gpio_set_intr_type(gpio, _detectPin.inverted() ? GPIO_INTR_NEGEDGE : GPIO_INTR_POSEDGE);
    gpio_isr_handler_add(gpio, plrISR, nullptr);

    xTaskCreatePinnedToCore(saveTask, "plr_save", 4096, nullptr, configMAX_PRIORITIES - 1, nullptr, 1);

    s_ready = true;

    // Boot-time check for a saved session. We don't auto-resume -- that
    // decision belongs to whoever is standing in front of the machine.
    PLR::SavedState saved {};
    if (loadSavedState(saved)) {
        s_pending_state  = saved;
        s_prompt_pending = true;
        buildSummary(saved);
        log_info("PLR: found saved session (" << saved.filename << ", line " << saved.line_number << ") -- resume from keypad/OLED");
        Buzzer::beep(880, 150);  // Attention tone -- a prompt is waiting on the OLED
    }
}

void PowerLossRecovery::deinit() {
    if (s_ready) {
        gpio_num_t gpio = (gpio_num_t)_detectPin.getNative(Pin::Capabilities::Input);
        gpio_isr_handler_remove(gpio);
        s_ready = false;
    }
}

ConfigurableModuleFactory::InstanceBuilder<PowerLossRecovery> __plr_module("power_loss_recovery");

// Strong definition of the hook declared (weak, returning false) in
// FileCommands.cpp. Called by runFile() right after it opens the file and
// before it starts the job: if this open is the one confirmResume() asked
// for, hand back where to seek to.
bool plr_take_resume_seek(const char* name, size_t& pos, size_t& line) {
    if (!s_seek_pending) {
        return false;
    }
    std::string a(name);
    std::string b(s_seek_file);
    if (!a.empty() && a[0] != '/') {
        a = "/" + a;
    }
    if (a != b) {
        return false;  // some other run request; leave the pending seek alone
    }
    s_seek_pending = false;
    pos            = s_seek_pos;
    line           = s_seek_line;
    return true;
}
