// Copyright (c) 2026 - Custom ESP32-S3 hardware integration
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

// PowerLossRecovery (PLR)
// ------------------------
// Detects an impending power loss on a dedicated GPIO (driven by an external
// brown-out / voltage-drop sense circuit backed by hold-up capacitors) and,
// within the surviving window, snapshots enough state to resume the current
// SD job after a cold boot: machine position, the SD job's filename/line
// number/byte offset, and the operationally significant G-code modal state
// (units, distance mode, active WCS, feed rate, spindle state/speed,
// coolant state).
//
// Latency design:
//   This deliberately does NOT use FluidNC's generic Pin/EventPin pin-event
//   system (Machine::EventPin, poll_gpios()). That system is polled from the
//   channel-service loop (see Serial.cpp: poll_gpios()) and is debounced on
//   the order of milliseconds -- fine for a human pressing a limit or feed
//   hold switch, but not a guaranteed bound for a brief capacitor hold-up
//   window. Instead this module installs its own IRAM-resident GPIO ISR that
//   does nothing but hand off to a dedicated FreeRTOS task created at
//   (configMAX_PRIORITIES - 1), i.e. above the Arduino loop task, WiFi/BT and
//   FluidNC's own stepper/protocol tasks, so the save routine preempts
//   everything else the instant the trigger fires.
//
// The actual SD write is therefore the dominant cost. At the SD SPI clock
// rates FluidNC typically uses (see sdcard: frequency_hz) a sub-100-byte
// write plus fflush/fclose is on the order of a few milliseconds to a few
// tens of milliseconds depending on the card. Size your hold-up capacitors
// with margin over a measurement on your own hardware -- this code cannot
// guarantee a specific number of microseconds, only that it starts writing
// essentially immediately after the trigger edge.

#pragma once

#include "Module.h"
#include "Pin.h"

#include <cstdint>
#include <cstdio>
#include <string>

namespace PLR {

    // Snapshot captured at trigger time and persisted to SD.
    struct SavedState {
        uint32_t magic;       // Format marker; also doubles as a minimal corruption check
        uint32_t version;     // Struct layout version
        char     filename[96];  // SD path of the job that was running
        uint32_t line_number;   // GCode line number (parser_state_t.line_number at trigger)
        uint32_t byte_offset;   // Byte offset into the file (JobSource::position())
        float    mpos[4];       // Machine position, X Y Z A, at trigger time
        uint8_t  n_axis;        // Number of axes actually populated in mpos[]
        uint8_t  units_inch;    // 1 = G20 (inch) was active, 0 = G21 (mm)
        uint8_t  distance_rel;  // 1 = G91 (incremental) was active, 0 = G90 (absolute)
        uint8_t  coord_select;  // CoordIndex of the active WCS (0=G54 .. 5=G59)
        float    feed_rate;     // mm/min, from gc_state.feed_rate
        uint8_t  spindle_state;  // 0=Unknown 3=Cw 4=Ccw 5=Disable (matches SpindleState)
        float    spindle_speed;  // RPM
        uint8_t  coolant_mist;
        uint8_t  coolant_flood;
        uint32_t checksum;  // Simple additive checksum over the fields above
    };

    // Queried by the OLED/Display module each refresh while idle, and by the
    // Keypad module to decide what Start/Stop should do. Returns false once
    // the prompt has been confirmed, cancelled, or there was nothing to resume.
    bool promptPending();

    // Human-readable summary line for the prompt screen, e.g.
    // "part.gcode  Ln 4213  X12.5 Y80.0". Valid only while promptPending().
    const char* promptSummary();

    // Called by the Keypad module (or any UI) when the operator chooses to
    // resume. Issues the modal-state preamble, repositions, and re-opens the
    // SD file at the saved line so streaming continues from there.
    void confirmResume();

    // Called when the operator declines. Deletes the saved-state file so it
    // is not offered again, and clears the prompt.
    void cancelResume();

}

// Registered via ConfigurableModuleFactory (see the InstanceBuilder line in
// the .cpp), the same mechanism OLED uses -- MachineConfig::group() already
// walks that factory generically, so a "power_loss_recovery:" YAML section
// is picked up with no changes needed to MachineConfig.cpp. This module does
// not use Module::poll(): ConfigurableModules are never polled by the
// central loop in this version of FluidNC (only init() is called on them;
// see Main.cpp), so instead of polling, this runs its own dedicated
// FreeRTOS task, woken by the ISR described above.
class PowerLossRecovery : public ConfigurableModule {
public:
    explicit PowerLossRecovery(const char* name) : ConfigurableModule(name) {}

    PowerLossRecovery(const PowerLossRecovery&)            = delete;
    PowerLossRecovery(PowerLossRecovery&&)                 = delete;
    PowerLossRecovery& operator=(const PowerLossRecovery&) = delete;
    PowerLossRecovery& operator=(PowerLossRecovery&&)      = delete;

    void init() override;
    void deinit() override;

    // Configuration
    void validate() override;
    void afterParse() override;
    void group(Configuration::HandlerBase& handler) override;

    ~PowerLossRecovery() override = default;

private:
    Pin         _detectPin;               // Power-fail sense input; fires the save ISR
    std::string _stateFile  = "/plr_state.bin";  // Path on the sd: volume
    float       _safeZ      = 0.0f;               // Machine-coordinate safe Z for resume
    bool        _enabled    = true;

    bool _error = false;
};
