// Copyright (c) 2026 - Custom ESP32-S3 hardware integration
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

// Buzzer
// ------
// Drives a passive piezo buzzer from a single LEDC PWM channel (via the
// existing Driver/PwmPin.h, the same abstraction FluidNC's spindle/laser PWM
// output uses -- see the comment on PwmPin::setFrequency() for why a single
// permanently-allocated channel is used instead of one PwmPin per note).
// Plays a short startup chime once at boot, then stays alive as a small
// FreeRTOS task blocked on a queue so other modules can request a beep
// (e.g. PowerLossRecovery announcing that a resume prompt is on screen)
// without blocking their own task waiting for the tone to finish.
#pragma once

#include "Module.h"
#include "Pin.h"

#include <cstdint>

namespace Buzzer {
    // Queues a single tone. Non-blocking: returns immediately, the tone
    // plays on the buzzer task. Safe to call before init() completes or if
    // no buzzer: section is configured -- it is simply a no-op then.
    void beep(uint32_t frequency_hz, uint32_t duration_ms);
}

class BuzzerModule : public ConfigurableModule {
public:
    explicit BuzzerModule(const char* name) : ConfigurableModule(name) {}

    BuzzerModule(const BuzzerModule&)            = delete;
    BuzzerModule(BuzzerModule&&)                 = delete;
    BuzzerModule& operator=(const BuzzerModule&) = delete;
    BuzzerModule& operator=(BuzzerModule&&)      = delete;

    void init() override;
    void deinit() override;

    void validate() override;
    void afterParse() override;
    void group(Configuration::HandlerBase& handler) override;

    ~BuzzerModule() override = default;

private:
    Pin  _outputPin;
    bool _startupMelody = true;
    bool _enabled        = true;

    bool _error = false;
};
