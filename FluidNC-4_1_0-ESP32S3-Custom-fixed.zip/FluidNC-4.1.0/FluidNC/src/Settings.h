#pragma once

#include "JSONEncoder.h"
#include "WebUI/Authentication.h"
#include "Report.h"  // info_channel
#include "GCode.h"   // CoordIndex

#include <string_view>
#include <map>
#include <Driver/NVS.h>
#include <functional>

// forward declarations
namespace Machine {
    class MachineConfig;
}

// Initialize the configuration subsystem
void settings_init();

// Define settings restore bitflags.
enum SettingsRestore {
    Defaults     = bitnum_to_mask(0),
    Parameters   = bitnum_to_mask(1),
    StartupLines = bitnum_to_mask(2),
    // BuildInfo = bitnum_to_mask(3), // Obsolete
    Wifi = bitnum_to_mask(4),
    All  = 0xff,
};

// Restore subsets of settings to default values
void settings_restore(uint8_t restore_flag);

// This abstract class defines the generic interface that
// is used to set and get values for all settings independent
// of their underlying data type.  The values are always
// represented as human-readable strings.  This generic
// interface is used for managing settings via the user interface.

// Derived classes implement these generic functions for different
// kinds of data.  Code that accesses settings should use only these
// generic functions and should not use derived classes directly.

typedef enum : uint8_t {
    GRBL = 1,  // Classic GRBL settings like $100
    EXTENDED,  // Settings added by early versions of Grbl_Esp32
    WEBSET,    // Settings for ESP3D_WebUI, stored in NVS
    PIN,       // Pin settings
    GRBLCMD,   // Non-persistent GRBL commands like $H
    WEBCMD,    // ESP3D_WebUI commands that are not directly settings
} type_t;

bool get_param(const char* parameter, const char* key, std::string& s);
bool paramIsJSON(const char* cmd_params);

typedef enum : uint8_t {
    WG,  // Readable and writable as guest
    WU,  // Readable and writable as user and admin
    WA,  // Readable as user and admin, writable as admin
} permissions_t;

class Word {
protected:
    const char*   _description;
    const char*   _grblName;
    const char*   _fullName;
    type_t        _type;
    permissions_t _permissions;

public:
    Word(type_t type, permissions_t permissions, const char* description, const char* grblName, const char* fullName);
    type_t        getType() { return _type; }
    permissions_t getPermissions() { return _permissions; }
    const char*   getName() { return _fullName; }
    const char*   getGrblName() { return _grblName; }
    const char*   getDescription() { return _description; }
};

class Command : public Word {
protected:
    bool (*_cmdChecker)();

private:
    // _needs_protocol_context: the command must execute on the protocol task
    //   because it touches the planner, the state machine, the event queue, or
    //   nests a job.  Commands without it are pure observers that can run off
    //   the protocol task.
    // _drains_buffer: call protocol_buffer_synchronize() before the command
    //   runs.  Only meaningful in the protocol context, so drains_buffer()
    //   ANDs the two ($J needs the context but must not block on the buffer).
    bool _needs_protocol_context = false;
    bool _drains_buffer          = false;

public:
    // Command::List is a vector of all commands,
    // so common code can enumerate them.
    static std::vector<Command*> List;

    ~Command() {}
    Command(const char*   description,
            type_t        type,
            permissions_t permissions,
            const char*   grblName,
            const char*   fullName,
            bool (*cmdChecker)(),
            bool needs_protocol_context = false,
            bool drains_buffer          = false);

    // The default implementation of addWebui() does nothing.
    // Derived classes may override it to do something.
    virtual void addWebui(JSONencoder*) {};

    virtual Error action(const char* value, AuthenticationLevel auth_level, Channel& out) = 0;

    bool needs_protocol_context() { return _needs_protocol_context; }
    bool drains_buffer() { return _needs_protocol_context && _drains_buffer; }
    // True if this command's state guard currently disallows it.
    bool disallowed() { return _cmdChecker && _cmdChecker(); }
};

class Setting : public Word {
private:
protected:
    // group_t _group;
    axis_t      _axis = INVALID_AXIS;
    const char* _keyName;

public:
    static void init();

    // Setting::List is a vector of all settings,
    // so common code can enumerate them.
    static std::vector<Setting*> List;

    Error check_state();

    static Error report_nvs_stats(const char* value, AuthenticationLevel auth_level, Channel& out) {
        size_t used, free, total;
        if (nvs.get_stats(used, free, total)) {
            return Error::NvsGetStatsFailed;
        }

        log_info("NVS Used:" << used << " Free:" << free << " Total:" << total);
        return Error::Ok;
    }

    static Error eraseNVS(const char* value, AuthenticationLevel auth_level, Channel& out) {
        nvs.erase_all();
        return Error::Ok;
    }

    ~Setting() {}
    Setting(const char* description, type_t type, permissions_t permissions, const char* grblName, const char* fullName);
    axis_t getAxis() { return _axis; }
    void   setAxis(axis_t axis) { _axis = axis; }

    // load() reads the backing store to get the current
    // value of the setting.  This could be slow so it
    // should be done infrequently, typically once at startup.
    virtual void load() {};
    virtual void setDefault() {};

    // The default implementation of addWebui() does nothing.
    // Derived classes may override it to do something.
    virtual void addWebui(JSONencoder*) {};

    virtual Error       setStringValue(std::string_view s) = 0;
    virtual const char* getStringValue()                   = 0;
    virtual const char* getCompatibleValue() { return getStringValue(); }
    virtual const char* getDefaultString() = 0;
};

class IntSetting : public Setting {
private:
    int32_t _defaultValue;
    int32_t _currentValue;
    int32_t _storedValue;
    int32_t _minValue;
    int32_t _maxValue;
    bool    _currentIsNvm;

public:
    IntSetting(const char*   description,
               type_t        type,
               permissions_t permissions,
               const char*   grblName,
               const char*   name,
               int32_t       defVal,
               int32_t       minVal,
               int32_t       maxVal,
               bool          currentIsNvm = false);

    IntSetting(type_t        type,
               permissions_t permissions,
               const char*   grblName,
               const char*   name,
               int32_t       defVal,
               int32_t       minVal,
               int32_t       maxVal,
               bool          currentIsNvm = false) :
        IntSetting(NULL, type, permissions, grblName, name, defVal, minVal, maxVal, currentIsNvm) {}

    void        load() override;
    void        setDefault() override;
    void        addWebui(JSONencoder*) override;
    Error       setStringValue(std::string_view s) override;
    const char* getStringValue() override;
    const char* getDefaultString() override;

    int32_t get() { return _currentValue; }
};

class FloatProxySetting : public Setting {
    float* _valuep;

public:
    FloatProxySetting(const char* grblName, const char* fullName, float* valuep) :
        Setting(fullName, type_t::GRBL, permissions_t::WU, grblName, fullName), _valuep(valuep) {}

    const char* getStringValue() override {
        static char strval[32];
        std::snprintf(strval, 31, "%.3f", *_valuep);
        return strval;
    }
    Error       setStringValue(std::string_view value) override { return Error::ReadOnlySetting; }
    const char* getDefaultString() override { return ""; }
};

// IntProxySetting needs a getter function instead of a simple value pointer
// because there are a variety of other ways to get the information, including
// function calls and type conversion from mask to bool
class IntProxySetting : public Setting {
    std::function<int(Machine::MachineConfig const&)> _getter;
    std::string                                       _cachedValue;

public:
    IntProxySetting(const char* grblName, const char* fullName, std::function<int(Machine::MachineConfig const&)> getter) :
        Setting(fullName, type_t::GRBL, permissions_t::WU, grblName, fullName), _getter(getter), _cachedValue("") {}
    const char* getStringValue() override;
    Error       setStringValue(std::string_view value) override { return Error::ReadOnlySetting; }
    const char* getDefaultString() override { return ""; }
};

class Coordinates {
private:
    float       _currentValue[MAX_N_AXIS];
    const char* _name;

public:
    Coordinates(const char* name) : _name(name) {}

    const char* getName() { return _name; }
    bool        load();
    bool        is_saved = true;  // is saved to NVS

    void setDefault() {
        float zeros[MAX_N_AXIS] = {
            0.0,
        };
        set(zeros);
    };
    // Copy the value to an array
    void get(float* value) { memcpy(value, _currentValue, sizeof(_currentValue)); }
    // Return a pointer to the array
    const float* get() { return _currentValue; }
    // Get an individual component
    float get(axis_t axis) { return _currentValue[axis]; }
    // Set an individual component
    void set(axis_t axis, float value) { _currentValue[axis] = value; }

    void set(float* value);
};

extern Coordinates* coords[CoordIndex::End];

class StringSetting : public Setting {
private:
    std::string _defaultValue;
    std::string _currentValue;
    std::string _storedValue;
    int32_t     _minLength;
    int32_t     _maxLength;
    void        _setStoredValue(const char* s);

public:
    StringSetting(const char*   description,
                  type_t        type,
                  permissions_t permissions,
                  const char*   grblName,
                  const char*   name,
                  const char*   defVal,
                  int32_t       min,
                  int32_t       max);

    StringSetting(type_t type, permissions_t permissions, const char* grblName, const char* name, const char* defVal) :
        StringSetting(NULL, type, permissions, grblName, name, defVal, 0, 0) {};

    void        load() override;
    void        setDefault() override;
    void        addWebui(JSONencoder*) override;
    Error       setStringValue(std::string_view s) override;
    const char* getStringValue() override;
    const char* getDefaultString() override;

    const char* get() { return _currentValue.c_str(); }
};

struct cmp_str {
    bool operator()(char const* a, char const* b) const { return strcasecmp(a, b) < 0; }
};
typedef std::map<const char*, int8_t, cmp_str> enum_opt_t;

class EnumSetting : public Setting {
private:
    int8_t                                        _defaultValue;
    int8_t                                        _storedValue;
    int8_t                                        _currentValue;
    const std::map<const char*, int8_t, cmp_str>* _options;
    const char*                                   enumToString(int8_t value);

public:
    EnumSetting(const char*       description,
                type_t            type,
                permissions_t     permissions,
                const char*       grblName,
                const char*       name,
                int8_t            defVal,
                const enum_opt_t* opts);

    EnumSetting(type_t type, permissions_t permissions, const char* grblName, const char* name, int8_t defVal, const enum_opt_t* opts) :
        EnumSetting(NULL, type, permissions, grblName, name, defVal, opts) {}

    void        load() override;
    void        setDefault() override;
    void        addWebui(JSONencoder*) override;
    Error       setStringValue(std::string_view s) override;
    const char* getStringValue() override;
    const char* getDefaultString() override;
    void        showList();

    int8_t get() { return _currentValue; }
};

extern bool notIdleOrJog();
extern bool notIdleOrAlarm();
extern bool anyState();
extern bool cycleOrHold();
extern bool allowConfigStates();

extern bool usedGrblName;

class IPaddrSetting : public Setting {
private:
    uint32_t _defaultValue;
    uint32_t _currentValue;
    uint32_t _storedValue;

public:
    IPaddrSetting(const char* description, type_t type, permissions_t permissions, const char* grblName, const char* name, uint32_t defVal);
    IPaddrSetting(const char* description, type_t type, permissions_t permissions, const char* grblName, const char* name, const char* defVal);

    void        load() override;
    void        setDefault() override;
    void        addWebui(JSONencoder*) override;
    Error       setStringValue(std::string_view s) override;
    const char* getStringValue() override;
    const char* getDefaultString() override;

    uint32_t get() { return _currentValue; }
};

class WebCommand : public Command {
private:
    Error (*_action)(const char*, AuthenticationLevel, Channel& out);
    const char* password;

protected:
    WebCommand(const char*   description,
               type_t        type,
               permissions_t permissions,
               const char*   grblName,
               const char*   name,
               Error (*action)(const char*, AuthenticationLevel, Channel& out),
               bool (*cmdChecker)(),
               bool          needs_protocol_context) :
        Command(description, type, permissions, grblName, name, cmdChecker, needs_protocol_context, /*drains_buffer=*/false),
        _action(action) {}

public:
    // [ESPxxx] commands touch the filesystem, NVS, the network, or restart the
    // box, so by default they must run on the protocol task; the read-only
    // status ones use WebReportCommand.
    WebCommand(const char*   description,
               type_t        type,
               permissions_t permissions,
               const char*   grblName,
               const char*   name,
               Error (*action)(const char*, AuthenticationLevel, Channel& out),
               bool (*cmdChecker)() = notIdleOrAlarm) :
        WebCommand(description, type, permissions, grblName, name, action, cmdChecker, /*needs_protocol_context=*/true) {}

    Error action(const char* value, AuthenticationLevel auth_level, Channel& out);
};

// A read-only [ESPxxx] status/info command with no protocol-task dependency.
class WebReportCommand : public WebCommand {
public:
    WebReportCommand(const char*   description,
                     type_t        type,
                     permissions_t permissions,
                     const char*   grblName,
                     const char*   name,
                     Error (*action)(const char*, AuthenticationLevel, Channel& out),
                     bool (*cmdChecker)() = anyState) :
        WebCommand(description, type, permissions, grblName, name, action, cmdChecker, /*needs_protocol_context=*/false) {}
};

class UserCommand : public Command {
private:
    Error (*_action)(const char*, AuthenticationLevel, Channel&);

public:
    UserCommand(const char* grblName,
                const char* name,
                Error (*action)(const char*, AuthenticationLevel, Channel&),
                bool (*cmdChecker)(),
                permissions_t auth                   = WG,
                bool          needs_protocol_context = true,
                bool          drains_buffer          = true) :
        Command(NULL, GRBLCMD, auth, grblName, name, cmdChecker, needs_protocol_context, drains_buffer),
        _action(action) {}

    Error action(const char* value, AuthenticationLevel auth_level, Channel& response);
};
// Feeds the planner but must stay responsive: runs in the protocol context
// without a preceding buffer sync.  (Currently just $J.)
class AsyncUserCommand : public UserCommand {
public:
    AsyncUserCommand(const char* grblName,
                     const char* name,
                     Error (*action)(const char*, AuthenticationLevel, Channel&),
                     bool (*cmdChecker)(),
                     permissions_t auth = WG) :
        UserCommand(grblName, name, action, cmdChecker, auth, /*needs_protocol_context=*/true, /*drains_buffer=*/false) {}
};
// A command with no protocol-task dependency: it touches no planner, no state
// machine, no event-queue consumer, and nests no job, so it runs on the
// polling task and never drains the motion buffer.  Most are pure reports; a
// few have a small non-motion side effect ($RI sets a channel's report
// interval, $SA posts an alarm event).
class ReportCommand : public UserCommand {
public:
    ReportCommand(const char* grblName,
                  const char* name,
                  Error (*action)(const char*, AuthenticationLevel, Channel&),
                  bool (*cmdChecker)()  = anyState,
                  permissions_t auth    = WG) :
        UserCommand(grblName, name, action, cmdChecker, auth, /*needs_protocol_context=*/false, /*drains_buffer=*/false) {}
};

// Execute the startup script lines stored in non-volatile storage upon initialization
Error settings_execute_line(const char* line, Channel& out, AuthenticationLevel);
Error do_command_or_setting(std::string_view key, std::string_view value, AuthenticationLevel auth_level, Channel&);
// on_protocol_task: true when called from protocol_main_loop (run it now);
// false when called from the polling task (run side-effect-free commands
// inline, hand anything needing the protocol context to cmd_queue, reject
// interloper gcode/commands during a job).
Error execute_line(const char* line, Channel& channel, AuthenticationLevel auth_level, bool on_protocol_task);

extern const enum_opt_t onoffOptions;
