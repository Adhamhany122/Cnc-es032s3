// Copyright (c) 2024 -  Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

// Stepping engine that uses direct GPIO accesses timed by spin loops.
// RP2040 timed engine using hardware timer at 1 MHz.

#include "Driver/step_engine.h"
#include "Driver/fluidnc_gpio.h"
#include "Driver/delay_usecs.h"
#include "StepTimer.h"

static uint32_t _pulse_delay_us;
static uint32_t _dir_delay_us;
// _stepPulseEndTime and _stepPulsePending are read/written from both the
// stepper timer ISR (via Stepping::step()/finish_step()) and the foreground
// reset path (Stepper::reset() -> stop_stepping() -> unstep()), so they're
// volatile to keep the compiler from caching stale values across contexts.
static volatile int32_t _stepPulseEndTime;

static uint32_t init_engine(uint32_t dir_delay_us, uint32_t pulse_delay_us, uint32_t& frequency, bool (*callback)(void)) {
    (void)frequency;

    stepTimerAttach(callback);
    _dir_delay_us   = dir_delay_us;
    _pulse_delay_us = pulse_delay_us;
    return _pulse_delay_us;
}

static uint32_t init_step_pin(pinnum_t step_pin, bool step_invert) {
    (void)step_invert;
    return step_pin;
}

static void set_pin(pinnum_t pin, bool level) {
    gpio_write(pin, level);
}

static void finish_dir() {
    delay_us(_dir_delay_us);
}

static void start_step() {}

// Instead of waiting here for the step end time, we mark when the
// step pulse should end, then return. The stepper code can then do
// some work that is overlapped with the pulse time. The spin loop
// will happen in start_unstep().
static volatile bool _stepPulsePending = false;

static void finish_step() {
    _stepPulseEndTime = usToEndTicks(_pulse_delay_us);
    _stepPulsePending = true;
}

static bool start_unstep() {
    // Only spin out the pulse width if a step pulse is actually in flight.
    // unstep() is also called from stop_stepping() on soft reset, where
    // _stepPulseEndTime is stale; spinUntil() compares against the RP2040's
    // free-running 1 MHz hardware timer, which wraps roughly every 71.6
    // minutes, so a stale deadline can spin for up to half of that and trip
    // the watchdog.
    if (_stepPulsePending) {
        _stepPulsePending = false;
        spinUntil(_stepPulseEndTime);
    }
    return false;
}

// This is a noop because each gpio_write() takes effect immediately,
// so there is no need to commit multiple GPIO changes.
static void finish_unstep() {}

static uint32_t max_pulses_per_sec() {
    return 1000000 / (2 * _pulse_delay_us);
}

static void set_timer_ticks(uint32_t ticks) {
    stepTimerSetTicks(ticks);
}

static void start_timer() {
    stepTimerStart();
}

static void stop_timer() {
    stepTimerStop();
}

static step_engine_t engine = {
    "Timed",
    init_engine,
    init_step_pin,
    set_pin,
    finish_dir,
    start_step,
    set_pin,
    finish_step,
    start_unstep,
    finish_unstep,
    max_pulses_per_sec,
    set_timer_ticks,
    start_timer,
    stop_timer,
    nullptr
};

REGISTER_STEP_ENGINE(Timed, &engine);